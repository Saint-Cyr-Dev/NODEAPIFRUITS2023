// index.js

require('dotenv').config();

const { PORT, MONGODB_USER, MONGODB_PASSWORD, MONGODB_CLUSTER, MONGODB_DATABASE } = process.env;

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();

// Middleware
app.use(bodyParser.json());

// MongoDB Connection
mongoose.connect(`mongodb+srv://${MONGODB_USER}:${MONGODB_PASSWORD}@${MONGODB_CLUSTER}.mongodb.net/${MONGODB_DATABASE}?retryWrites=true&w=majority`, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'ERROR: CANNOT CONNECT TO MONGO-DB'));
db.once('open', () => console.log('CONNECTED TO MONGO DB'));

// Importer le routeur administratif
const adminRouter = require('./routers/admin-router');
app.use('/admin/', adminRouter);

// Vos autres routes et configurations vont ici

// Start the server
app.listen(PORT, () =>
  console.log(`Application lancée sur le port ${PORT} !!!`)
);
