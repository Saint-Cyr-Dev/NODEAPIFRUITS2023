// admin-router.js

const express = require('express');
const crypto = require('crypto');
const User = require('../model/user');
const RecoveryPassword = require('../model/recovery-password-model');

const router = express.Router();

// ... (le reste du code du routeur)

// Route POST pour la récupération de mot de passe
router.post('/recovery-password', async (req, res) => {
  try {
    const { email } = req.body;

    // Vérifier si l'utilisateur existe
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: 'Aucun utilisateur trouvé avec cet e-mail' });
    }

    // Générer un slug aléatoire
    const slug = crypto.randomBytes(20).toString('hex');

    // Enregistrer le slug dans la collection RecoveryPassword
    const recoveryPassword = new RecoveryPassword({ userId: user._id, slug });
    await recoveryPassword.save();

    // Envoyer un lien avec le slug à l'utilisateur (dans une application réelle, cela impliquerait l'envoi d'un e-mail)
    const recoveryLink = `http://localhost:3000/reset-password/${slug}`;

    // Retourner un message de succès
    res.json({ message: 'Un lien de récupération de mot de passe a été envoyé à votre adresse e-mail.', recoveryLink });
  } catch (error) {
    console.error('Erreur lors de la récupération du mot de passe :', error);
    res.status(500).json({ message: 'Erreur lors de la récupération du mot de passe' });
  }
});

// Route POST pour définir un nouveau mot de passe
router.post('/new-password', async (req, res) => {
  try {
    const { slug, newPassword } = req.body;

    // Rechercher le slug dans la collection RecoveryPassword
    const recoveryPassword = await RecoveryPassword.findOne({ slug });

    if (!recoveryPassword) {
      return res.status(404).json({ message: 'Lien de récupération de mot de passe invalide' });
    }

    // Mettre à jour le mot de passe de l'utilisateur dans la collection Users
    const user = await User.findById(recoveryPassword.userId);

    if (!user) {
      return res.status(404).json({ message: 'Utilisateur non trouvé' });
    }

    user.setPassword(newPassword);
    await user.save();

    // Supprimer le document de récupération de mot de passe après utilisation
    await RecoveryPassword.findByIdAndRemove(recoveryPassword._id);

    // Retourner un message de succès
    res.json({ message: 'Mot de passe mis à jour avec succès' });
  } catch (error) {
    console.error('Erreur lors de la mise à jour du mot de passe :', error);
    res.status(500).json({ message: 'Erreur lors de la mise à jour du mot de passe' });
  }
});

module.exports = router;
