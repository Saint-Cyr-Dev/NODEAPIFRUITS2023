const User = require('../model/user');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const mailPattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
const passwordPattern = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;

module.exports = {
    checkAuthPayload: (req, res, next) => {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ message: 'Adresse e-mail ou mot de passe manquant' });
        }

        req.email = email;
        req.password = password;
        next();
    },

    checkEmailPayload: (req, res, next) => {
        const { email } = req;

        if (!mailPattern.test(email)) {
            return res.status(400).json({ message: 'Format d\'e-mail invalide' });
        }

        next();
    },

    checkPasswordPayload: (req, res, next) => {
        const { password } = req;

        if (!passwordPattern.test(password)) {
            const errors = [];

            // (code de validation du mot de passe)

            return res.status(400).json({ message: "Votre mot de passe n'est pas conforme", errors });
        }

        next();
    },

    signupResponse: async (req, res) => {
        try {
            const { email, password } = req;
    
            // Vérifie si l'utilisateur existe déjà
            const existingUser = await User.findOne({ email });
    
            if (existingUser) {
                return res.status(400).json({ message: 'Email déjà utilisé.' });
            }
    
            // Si l'utilisateur n'existe pas, enregistre le nouvel utilisateur
            const newUser = new User({
                email,
                ingredients: [],
            });
    
            newUser.setPassword(password);

            // Enregistrez l'utilisateur dans la base de données
            const savedUser = await newUser.save();
    
            if (!savedUser) {
                return res.status(500).json({ message: "Erreur lors de l'enregistrement de l'utilisateur." });
            }
    
            // Générer le token JWT
            const token = savedUser.generateJWT();
    
            // Renvoyer une réponse avec le token
            res.status(201).json({ message: 'Utilisateur enregistré avec succès.', token });
        } catch (error) {
            let status = 500;
            let message = 'Erreur inattendue.';
            if (error.message === 'Utilisateur déjà existant.') status = 400;
    
            console.error(new Date().toISOString(), 'controllers/admin-controllers.js > signupResponse > error ', error);
    
            return res.status(status).json({ message });
        }
    },
};
