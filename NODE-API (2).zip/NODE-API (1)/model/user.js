// user.js

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const userSchema = new Schema(
  {
    email: {
      type: String,
      unique: true,
      required: [true, 'Please add an email'],
    },
    ingredients: {
      type: [String],
    },
    salt: {
      type: String,
    },
    hash: {
      type: String,
    },
    recoveryPassword: { type: mongoose.Schema.Types.ObjectId, ref: 'RecoveryPassword' },
  },
  { collection: 'users' }
);

// ... (le reste du code du modèle User)
